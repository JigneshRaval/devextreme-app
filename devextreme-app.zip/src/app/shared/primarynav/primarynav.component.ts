import { Component } from '@angular/core';

@Component({
  selector: 'ah-primarynav',
  templateUrl: './primarynav.component.html',
  styleUrls: ['./primarynav.component.css']
})
export class PrimarynavComponent {}