import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ah-resources',
  templateUrl: './resources.component.html',
  styleUrls: ['./resources.component.css']
})
export class ResourcesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
