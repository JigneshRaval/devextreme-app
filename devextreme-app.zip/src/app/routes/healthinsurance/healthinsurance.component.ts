import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ah-healthinsurance',
  templateUrl: './healthinsurance.component.html',
  styleUrls: ['./healthinsurance.component.css']
})
export class HealthinsuranceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
