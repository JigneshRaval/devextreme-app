import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ah-otherbenefits',
  templateUrl: './otherbenefits.component.html',
  styleUrls: ['./otherbenefits.component.css']
})
export class OtherbenefitsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
